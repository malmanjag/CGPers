class LoginPage:
    def __init__(self,driver):
        self.driver = driver

    def setUserName(self,userName):
        self.driver.find_element_by_id("txtUsername").clear()
        self.driver.find_element_by_id("txtUsername").send_keys(userName)

    def setPassword(self,password):
        self.driver.find_element_by_id("txtPassword").clear()
        self.driver.find_element_by_id("txtPassword").send_keys(password)

    def clickLogin(self):
        self.driver.find_element_by_id("btnLogin").click()

