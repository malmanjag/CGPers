class HomePage:
    def __init__(self,driver):
        self.driver = driver

    def clickWelcomeLink(self):
        self.driver.find_element_by_id("welcome").click()

    def clickLogout(self):
        self.driver.find_element_by_link_text("Logout").click()

    def clickMasterPlace(self):
        self.driver.find_element_by_id("MP_link").click()