from selenium import webdriver
import unittest
import HtmlTestRunner
import sys
import os

#sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))

from Pages.Login.login_page import LoginPage
from Pages.Home.home_page import HomePage

directory = os.getcwd()

class SanityTestSuite(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print("Initiating setup")
        cls.driver = webdriver.Chrome(executable_path="C:/Users/mjegathe/PycharmProjects/OrangeHRM_TestAutomation/Drivers/chromedriver.exe")
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    def test_01_login(self):
        print("Execution commenced")
        driver = self.driver
        driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login")
        login = LoginPage(driver)
        login.setUserName("Admin")
        login.setPassword("admin123")
        login.clickLogin()
        print("Execution completed")

    def test_03_logout(self):
        print("Execution of logout commenced")
        driver = self.driver
        homepage = HomePage(driver)
        homepage.clickWelcomeLink()
        homepage.clickLogout()
        print("Out of Logout")

    def test_02_masterplace_load(self):
        driver = self.driver
        homepage = HomePage(driver)
        homepage.clickMasterPlace()
        driver.implicitly_wait(10)
        print("clickedMasterPlace")


    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Teardown completed")
        outfile = open(directory + "/SeleniumPythonTestSummary.html", "w")
        print("Inside Reporting method")


if __name__ == '__main__':
    #unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:/Users/mjegathe/PycharmProjects/OrangeHRM_TestAutomation/Reports'))
    #outfile = open(directory + "/SeleniumPythonTestSummary.html", "w")
    print("Inside Reporting method")
